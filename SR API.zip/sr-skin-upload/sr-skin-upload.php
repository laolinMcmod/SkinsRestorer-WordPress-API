<?php
/**
 * Plugin Name: SR皮肤上传（对接Minecraft SkinsRestorer SrWebApi）
 * Plugin URI: https://gitee.com/你的仓库地址
 * Description: Use shortcode [sr_skin] to add MC skin upload form. Upload PNG skins to Minecraft SkinsRestorer.
 * Version: 1.0
 * Author: BoblinChina
 * License: MIT
 * Text Domain: sr-skin-upload
 * Domain Path: /languages
 * Requires PHP: 8.1
 * Requires at least: 6.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// 加载语言包
add_action('plugins_loaded', 'sr_skin_load_textdomain');
function sr_skin_load_textdomain()
{
    load_plugin_textdomain(
        'sr-skin-upload',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages/'
    );
}

// ====================== 后台设置页面 ======================
add_action('admin_menu', 'sr_skin_add_admin_menu');
add_action('admin_init', 'sr_skin_register_settings');

function sr_skin_add_admin_menu()
{
    add_options_page(
        __('SR皮肤上传设置', 'sr-skin-upload'),
        __('SR皮肤设置', 'sr-skin-upload'),
        'manage_options',
        'sr-skin-setting',
        'sr_skin_render_admin_page'
    );
}

function sr_skin_register_settings()
{
    register_setting('sr_skin_settings_group', 'sr_mc_host');
    register_setting('sr_skin_settings_group', 'sr_mc_port');
    register_setting('sr_skin_settings_group', 'sr_is_bound');
}

function sr_skin_render_admin_page()
{
    $mc_host    = get_option('sr_mc_host', '127.0.0.1');
    $mc_port    = get_option('sr_mc_port', '25580');
    $is_bound   = get_option('sr_is_bound', false);
    $website_domain = get_site_url();
    $bind_msg   = '';

    // 处理服务器绑定提交，增加nonce安全校验
    if (isset($_POST['sr_bind_submit'])) {
        if (!isset($_POST['sr_admin_nonce']) || !wp_verify_nonce($_POST['sr_admin_nonce'], 'sr_admin_bind_action')) {
            wp_die(__("非法请求", 'sr-skin-upload'));
        }
        $token = sanitize_text_field($_POST['sr_onekey_input']);
        $api_url = "http://{$mc_host}:{$mc_port}/api/skin";
        $post_data = json_encode([
            'token'      => $token,
            'wp_domain'  => $website_domain
        ]);

        $response = wp_remote_post($api_url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => $post_data,
            'timeout' => 15
        ]);

        if (is_wp_error($response)) {
            $bind_msg = '<div class="notice notice-error"><p>❌ ' . esc_html(sprintf(__('请求失败：%s', 'sr-skin-upload'), $response->get_error_message())) . '</p></div>';
        } else {
            $resp_body = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($resp_body['code']) && $resp_body['code'] === 200) {
                update_option('sr_is_bound', true);
                $bind_msg = '<div class="notice notice-success"><p>✅ ' . esc_html(__('MC服务器绑定成功！一次性密钥已自动失效。', 'sr-skin-upload')) . '</p></div>';
            } else {
                $msg = $resp_body['msg'] ?? __('未知错误', 'sr-skin-upload');
                $bind_msg = '<div class="notice notice-error"><p>❌ ' . esc_html($msg) . '</p></div>';
            }
        }
    }

    ?>
    <div class="wrap">
        <h1><?php esc_html_e('SR皮肤上传 — 服务器绑定设置', 'sr-skin-upload'); ?></h1>
        <?php echo $bind_msg; ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('sr_skin_settings_group');
            do_settings_sections('sr_skin_settings_group');
            ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('MC服务器IP/域名', 'sr-skin-upload'); ?></th>
                    <td><input type="text" name="sr_mc_host" value="<?php echo esc_attr($mc_host); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('SrWebApi端口', 'sr-skin-upload'); ?></th>
                    <td><input type="number" name="sr_mc_port" value="<?php echo esc_attr($mc_port); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('绑定状态', 'sr-skin-upload'); ?></th>
                    <td>
                        <?php
                        if ($is_bound) {
                            echo '<span style="color:green; font-weight:bold">✅ ' . esc_html__('已绑定MC服务器', 'sr-skin-upload') . '</span>';
                        } else {
                            echo '<span style="color:red; font-weight:bold">❌ ' . esc_html__('未绑定', 'sr-skin-upload') . '</span>';
                        }
                        ?>
                    </td>
                </tr>
            </table>
            <?php submit_button(__('保存基础设置', 'sr-skin-upload')); ?>
        </form>

        <hr>
        <h2><?php esc_html_e('一次性OneKey绑定（在MC控制台输入 srapi onekey 获取）', 'sr-skin-upload'); ?></h2>
        <form method="post">
            <?php wp_nonce_field('sr_admin_bind_action','sr_admin_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('一次性绑定密钥', 'sr-skin-upload'); ?></th>
                    <td><input type="text" name="sr_onekey_input" class="large-text" placeholder="<?php esc_attr_e('粘贴MC控制台生成的密钥', 'sr-skin-upload'); ?>"></td>
                </tr>
            </table>
            <input type="submit" name="sr_bind_submit" class="button button-primary" value="<?php esc_attr_e('绑定MC服务器', 'sr-skin-upload'); ?>">
            <p class="description">⚠️ <?php esc_html_e('该密钥仅可使用一次！绑定成功自动作废，如需重新绑定，需要在MC控制台再次执行 srapi onekey。', 'sr-skin-upload'); ?></p>
        </form>
    </div>
    <?php
}

// ====================== 简码 [sr_skin] 皮肤上传表单 ======================
add_shortcode('sr_skin', 'sr_skin_render_upload_form');
function sr_skin_render_upload_form()
{
    ob_start();
    $is_bound = get_option('sr_is_bound', false);
    $mc_host  = get_option('sr_mc_host');
    $mc_port  = get_option('sr_mc_port');
    $msg = '';

    // 处理皮肤提交
    if (isset($_POST['sr_skin_submit'])) {
        if (!isset($_POST['sr_front_nonce']) || !wp_verify_nonce($_POST['sr_front_nonce'], 'sr_front_upload_action')) {
            wp_die(__("非法请求", 'sr-skin-upload'));
        }
        $player_name = sanitize_text_field($_POST['sr_player_name']);
        if (empty($player_name)) {
            $msg = '<div style="color:red">❌ ' . esc_html(__('请填写你的MC游戏ID！', 'sr-skin-upload')) . '</div>';
        } elseif (!isset($_FILES['sr_skin_file']) || $_FILES['sr_skin_file']['error'] !== UPLOAD_ERR_OK) {
            $msg = '<div style="color:red">❌ ' . esc_html(__('请上传皮肤PNG文件！', 'sr-skin-upload')) . '</div>';
        } else {
            $file_info = wp_check_filetype($_FILES['sr_skin_file']['name']);
            if ($file_info['ext'] !== 'png') {
                $msg = '<div style="color:red">❌ ' . esc_html(__('只支持PNG格式MC皮肤！', 'sr-skin-upload')) . '</div>';
            } else {
                $file_data = file_get_contents($_FILES['sr_skin_file']['tmp_name']);
                $base64_skin = base64_encode($file_data);

                $api_url = "http://{$mc_host}:{$mc_port}/api/upload_skin";
                $post_data = json_encode([
                    'player' => $player_name,
                    'skin'   => $base64_skin
                ]);

                $response = wp_remote_post($api_url, [
                    'headers' => ['Content-Type' => 'application/json'],
                    'body'    => $post_data,
                    'timeout' => 20
                ]);

                if (is_wp_error($response)) {
                    $msg = '<div style="color:red">❌ ' . esc_html(sprintf(__('连接MC服务器失败：%s', 'sr-skin-upload'), $response->get_error_message())) . '</div>';
                } else {
                    $resp = json_decode(wp_remote_retrieve_body($response), true);
                    if ($resp['code'] === 200) {
                        $msg = '<div style="color:green">✅ ' . esc_html(__('皮肤上传成功！在线玩家会立刻换肤，离线玩家下次进服自动加载。', 'sr-skin-upload')) . '</div>';
                    } else {
                        $msg = '<div style="color:red">❌ ' . esc_html($resp['msg']) . '</div>';
                    }
                }
            }
        }
    }

    if (!$is_bound) {
        echo '<div style="padding:10px; border:1px solid red; background:#ffebeb;">❌ ' . esc_html(__('还没有绑定MC服务器！请前往【设置 → SR皮肤设置】完成服务器绑定。', 'sr-skin-upload')) . '</div>';
        return ob_get_clean();
    }
    ?>
    <div style="max-width:520px; padding:20px; border:1px solid #ddd; border-radius:8px; background:#fff;">
        <h3><?php esc_html_e('MC皮肤上传（SkinsRestorer）', 'sr-skin-upload'); ?></h3>
        <?php echo $msg; ?>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('sr_front_upload_action','sr_front_nonce'); ?>
            <p>
                <label><?php esc_html_e('游戏ID：', 'sr-skin-upload'); ?></label>
                <input type="text" name="sr_player_name" required placeholder="<?php esc_attr_e('填写你的MC玩家名', 'sr-skin-upload'); ?>" style="width:100%;padding:6px;">
            </p>
            <p>
                <label><?php esc_html_e('上传皮肤PNG：', 'sr-skin-upload'); ?></label>
                <input type="file" name="sr_skin_file" accept=".png" required style="width:100%;">
                <small><?php esc_html_e('仅支持PNG，标准MC皮肤尺寸64×64 / 64×32', 'sr-skin-upload'); ?></small>
            </p>
            <p>
                <input type="submit" name="sr_skin_submit" value="<?php esc_attr_e('提交皮肤', 'sr-skin-upload'); ?>" class="button button-primary" style="padding:6px 16px;">
            </p>
        </form>
    </div>
    <?php
    return ob_get_clean();
}
