=== SR Skin Uploader ===
Contributors: BoblinChina
Tags: minecraft, skin, skinsrestorer, mc,皮肤
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WordPress简码插件，用于Minecraft服务器官网，给玩家提供皮肤上传入口，对接 SkinsRestorer + SrWebApi Bukkit插件。

== Description ==
使用简码 `[sr_skin]` 在文章/页面嵌入皮肤上传表单。
玩家在网站上传PNG皮肤，提交到你的MC服务端SrWebApi插件，自动对接SkinsRestorer更换皮肤。

功能：
* 一键简码嵌入表单 `[sr_skin]`
* 后台可视化配置API地址、密钥、一次性绑定码
* 中英双语国际化(I18N)
* 防跨站请求安全校验
* PHP8.5兼容

== Installation ==
1. 上传插件压缩包到WordPress插件目录，解压启用
2. 设置页面：设置 → SR皮肤上传
3. 填入MC服务端SrWebApi的API地址、密钥、一次性绑定码
4. 在页面添加简码 `[sr_skin]`

== Changelog ==
= 1.0.0 =
* 初版发布，基础皮肤上传功能
* I18N中英双语支持
* 对接SrWebApi一次性密钥绑定

== Screenshots ==
1. 前台皮肤上传表单
2. 后台设置页面